# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class AntPath(Component):
    """An AntPath component.


Keyword arguments:

- children (a list of or a singular dash component, string or number; optional):
    Optional child components like popups or tooltips.

- id (string; optional):
    The ID used to identify this component.

- attribution (string; optional)

- clickData (dict; optional):
    Data from the latest click event.

- color (string; optional):
    Base color of the path.

- dashArray (string | list of 2 elements: [number, number]; optional):
    Size of the animated dashes [dash_size, gap_size].

- delay (number; optional):
    Animation delay in milliseconds.

- eventHandlers (dict; optional)

    `eventHandlers` is a dict with keys:

    - baselayerchange (dict; optional)

        `baselayerchange` is a dict with keys:


    - overlayadd (dict; optional)

        `overlayadd` is a dict with keys:


    - overlayremove (dict; optional)

        `overlayremove` is a dict with keys:


    - layeradd (dict; optional)

        `layeradd` is a dict with keys:


    - layerremove (dict; optional)

        `layerremove` is a dict with keys:


    - zoomlevelschange (dict; optional)

        `zoomlevelschange` is a dict with keys:


    - unload (dict; optional)

        `unload` is a dict with keys:


    - viewreset (dict; optional)

        `viewreset` is a dict with keys:


    - load (dict; optional)

        `load` is a dict with keys:


    - zoomstart (dict; optional)

        `zoomstart` is a dict with keys:


    - movestart (dict; optional)

        `movestart` is a dict with keys:


    - zoom (dict; optional)

        `zoom` is a dict with keys:


    - move (dict; optional)

        `move` is a dict with keys:


    - zoomend (dict; optional)

        `zoomend` is a dict with keys:


    - moveend (dict; optional)

        `moveend` is a dict with keys:


    - autopanstart (dict; optional)

        `autopanstart` is a dict with keys:


    - dragstart (dict; optional)

        `dragstart` is a dict with keys:


    - drag (dict; optional)

        `drag` is a dict with keys:


    - add (dict; optional)

        `add` is a dict with keys:


    - remove (dict; optional)

        `remove` is a dict with keys:


    - loading (dict; optional)

        `loading` is a dict with keys:


    - error (dict; optional)

        `error` is a dict with keys:


    - update (dict; optional)

        `update` is a dict with keys:


    - down (dict; optional)

        `down` is a dict with keys:


    - predrag (dict; optional)

        `predrag` is a dict with keys:


    - resize (dict; optional)

        `resize` is a dict with keys:


    - popupopen (dict; optional)

        `popupopen` is a dict with keys:


    - popupclose (dict; optional)

        `popupclose` is a dict with keys:


    - tooltipopen (dict; optional)

        `tooltipopen` is a dict with keys:


    - tooltipclose (dict; optional)

        `tooltipclose` is a dict with keys:


    - locationerror (dict; optional)

        `locationerror` is a dict with keys:


    - locationfound (dict; optional)

        `locationfound` is a dict with keys:


    - click (dict; optional)

        `click` is a dict with keys:


    - dblclick (dict; optional)

        `dblclick` is a dict with keys:


    - mousedown (dict; optional)

        `mousedown` is a dict with keys:


    - mouseup (dict; optional)

        `mouseup` is a dict with keys:


    - mouseover (dict; optional)

        `mouseover` is a dict with keys:


    - mouseout (dict; optional)

        `mouseout` is a dict with keys:


    - mousemove (dict; optional)

        `mousemove` is a dict with keys:


    - contextmenu (dict; optional)

        `contextmenu` is a dict with keys:


    - preclick (dict; optional)

        `preclick` is a dict with keys:


    - keypress (dict; optional)

        `keypress` is a dict with keys:


    - keydown (dict; optional)

        `keydown` is a dict with keys:


    - keyup (dict; optional)

        `keyup` is a dict with keys:


    - zoomanim (dict; optional)

        `zoomanim` is a dict with keys:


    - dragend (dict; optional)

        `dragend` is a dict with keys:


    - tileunload (dict; optional)

        `tileunload` is a dict with keys:


    - tileloadstart (dict; optional)

        `tileloadstart` is a dict with keys:


    - tileload (dict; optional)

        `tileload` is a dict with keys:


    - tileabort (dict; optional)

        `tileabort` is a dict with keys:


    - tileerror (dict; optional)

        `tileerror` is a dict with keys:


- hardwareAccelerated (boolean; optional):
    Whether to use hardware acceleration.

- interactive (boolean; optional):
    Whether the path should respond to mouse/touch events.

- key (string | number; optional)

- n_clicks (number; optional):
    Number of times the path has been clicked.

- pane (string; optional)

- paused (boolean; optional):
    Whether the animation starts paused.

- positions (boolean | number | string | dict | list; required):
    Array of [lat,lng] points defining the path.

- pulseColor (string; optional):
    Color of the animated dash flow.

- ref (string; optional):
    Allows getting a ref to the component instance. Once the component
    unmounts, React will set `ref.current` to `None` (or call the ref
    with `None` if you passed a callback ref). @,see,,{@link
    ,https://react.dev/learn/referencing-values-with-refs#refs-and-the-dom
    React Docs,}.

- reverse (boolean; optional):
    Whether to reverse animation direction.

- weight (number; optional):
    Width of the path in pixels."""
    _children_props = []
    _base_nodes = ['children']
    _namespace = 'dash_leaflet'
    _type = 'AntPath'
    @_explicitize_args
    def __init__(self, children=None, id=Component.UNDEFINED, positions=Component.REQUIRED, delay=Component.UNDEFINED, dashArray=Component.UNDEFINED, pulseColor=Component.UNDEFINED, color=Component.UNDEFINED, weight=Component.UNDEFINED, paused=Component.UNDEFINED, reverse=Component.UNDEFINED, hardwareAccelerated=Component.UNDEFINED, interactive=Component.UNDEFINED, n_clicks=Component.UNDEFINED, clickData=Component.UNDEFINED, eventHandlers=Component.UNDEFINED, pane=Component.UNDEFINED, attribution=Component.UNDEFINED, ref=Component.UNDEFINED, key=Component.UNDEFINED, **kwargs):
        self._prop_names = ['children', 'id', 'attribution', 'clickData', 'color', 'dashArray', 'delay', 'eventHandlers', 'hardwareAccelerated', 'interactive', 'key', 'n_clicks', 'pane', 'paused', 'positions', 'pulseColor', 'ref', 'reverse', 'weight']
        self._valid_wildcard_attributes =            []
        self.available_properties = ['children', 'id', 'attribution', 'clickData', 'color', 'dashArray', 'delay', 'eventHandlers', 'hardwareAccelerated', 'interactive', 'key', 'n_clicks', 'pane', 'paused', 'positions', 'pulseColor', 'ref', 'reverse', 'weight']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs and excess named props
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}

        for k in ['positions']:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')

        super(AntPath, self).__init__(children=children, **args)
