# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class Tooltip(Component):
    """A Tooltip component.
Used to display small texts on top of map layers.

Keyword arguments:

- children (a list of or a singular dash component, string or number; optional):
    Children [MUTABLE].

- id (string; optional):
    Unique ID to identify this component in Dash callbacks.

- attribution (string; optional):
    String to be shown in the attribution control, e.g. \"©
    OpenStreetMap contributors\". It describes the layer data and is
    often a legal obligation towards copyright holders and tile
    providers. [MUTABLE].

- bubblingMouseEvents (boolean; optional):
    When True, a mouse event on this layer will trigger the same event
    on the map (unless L.DomEvent.stopPropagation is used).

- className (string; optional):
    A custom CSS class name to assign to the overlay.

- clickData (dict; optional):
    An object holding data related to the click event. Typing is
    indicative.

    `clickData` is a dict with keys:

    - latlng (list of numbers; required)

    - layerPoint (list of numbers; required)

    - containerPoint (list of numbers; required)

- content (dict; optional):
    Sets the HTML content of the overlay while initializing. If a
    function is passed the source layer will be passed to the
    function. The function should return a String or HTMLElement to be
    used in the overlay.

    `content` is a string | dict with keys:

    - accessKey (string; required)

    - accessKeyLabel (string; required)

    - autocapitalize (string; required)

    - dir (string; required)

    - draggable (boolean; required)

    - hidden (boolean; required)

    - inert (boolean; required)

    - innerText (string; required)

    - lang (string; required)

    - offsetHeight (number; required)

    - offsetLeft (number; required)

    - offsetParent (a list of or a singular dash component, string or number; required)

    - offsetTop (number; required)

    - offsetWidth (number; required)

    - outerText (string; required)

    - spellcheck (boolean; required)

    - title (string; required)

    - translate (boolean; required)

    - attachInternals (required)

    - click (required)

    - addEventListener (required)

    - removeEventListener (required)

    - attributes (dict; required)

        `attributes` is a dict with strings as keys and values of type
        dict with keys:

        - localName (string; required)

        - name (string; required)

        - namespaceURI (string; required)

        - ownerDocument (boolean | number | string | dict | list; required)

        - ownerElement (a list of or a singular dash component, string or number; required)

        - prefix (string; required)

        - specified (boolean; required)

        - value (string; required)

        - baseURI (string; required):

            Returns node's node document's document base URL.

        - childNodes (dict with strings as keys and values of type boolean | number | string | dict | list; required):

            Returns the children.

        - firstChild (boolean | number | string | dict | list; required):

            Returns the first child.

        - isConnected (boolean; required):

            Returns True if node is connected and False otherwise.

        - lastChild (boolean | number | string | dict | list; required):

            Returns the last child.

        - nextSibling (boolean | number | string | dict | list; required):

            Returns the next sibling.

        - nodeName (string; required):

            Returns a string appropriate for the type of node.

        - nodeType (number; required):

            Returns the type of node.

        - nodeValue (string; required)

        - parentElement (boolean | number | string | dict | list; required):

            Returns the parent element.

        - parentNode (boolean | number | string | dict | list; required):

            Returns the parent.

        - previousSibling (boolean | number | string | dict | list; required):

            Returns the previous sibling.

        - textContent (string; required)

        - appendChild (required)

        - cloneNode (required):

            Returns a copy of node. If deep is True, the copy also

            includes the node's descendants.

        - compareDocumentPosition (required):

            Returns a bitmask indicating the position of other relative to

            node.

        - contains (required):

            Returns True if other is an inclusive descendant of node, and

            False otherwise.

        - getRootNode (required):

            Returns node's root.

        - hasChildNodes (required):

            Returns whether node has children.

        - insertBefore (required)

        - isDefaultNamespace (required)

        - isEqualNode (required):

            Returns whether node and otherNode have the same properties.

        - isSameNode (required)

        - lookupNamespaceURI (required)

        - lookupPrefix (required)

        - normalize (required):

            Removes empty exclusive Text nodes and concatenates the data

            of remaining contiguous exclusive Text nodes into the first of

            their nodes.

        - removeChild (required)

        - replaceChild (required)

        - ATTRIBUTE_NODE (number; required)

        - CDATA_SECTION_NODE (number; required):

            node is a CDATASection node.

        - COMMENT_NODE (number; required):

            node is a Comment node.

        - DOCUMENT_FRAGMENT_NODE (number; required):

            node is a DocumentFragment node.

        - DOCUMENT_NODE (number; required):

            node is a document.

        - DOCUMENT_POSITION_CONTAINED_BY (number; required):

            Set when other is a descendant of node.

        - DOCUMENT_POSITION_CONTAINS (number; required):

            Set when other is an ancestor of node.

        - DOCUMENT_POSITION_DISCONNECTED (number; required):

            Set when node and other are not in the same tree.

        - DOCUMENT_POSITION_FOLLOWING (number; required):

            Set when other is following node.

        - DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC (number; required)

        - DOCUMENT_POSITION_PRECEDING (number; required):

            Set when other is preceding node.

        - DOCUMENT_TYPE_NODE (number; required):

            node is a doctype.

        - ELEMENT_NODE (number; required):

            node is an element.

        - ENTITY_NODE (number; required)

        - ENTITY_REFERENCE_NODE (number; required)

        - NOTATION_NODE (number; required)

        - PROCESSING_INSTRUCTION_NODE (number; required):

            node is a ProcessingInstruction node.

        - TEXT_NODE (number; required):

            node is a Text node.

        - addEventListener (required):

            Appends an event listener for events whose type attribute

            value is type. The callback argument sets the callback that

            will be invoked when the event is dispatched.  The options

            argument sets listener-specific options. For compatibility

            this can be a boolean, in which case the method behaves

            exactly as if the value was specified as options's capture.

            When set to True, options's capture prevents callback from

            being invoked when the event's eventPhase attribute value is

            BUBBLING_PHASE. When False (or not present), callback will not

            be invoked when event's eventPhase attribute value is

            CAPTURING_PHASE. Either way, callback will be invoked if

            event's eventPhase attribute value is AT_TARGET.  When set to

            True, options's passive indicates that the callback will not

            cancel the event by invoking preventDefault(). This is used to

            enable performance optimizations described in § 2.8 Observing

            event listeners.  When set to True, options's once indicates

            that the callback will only be invoked once after which the

            event listener will be removed.  If an AbortSignal is passed

            for options's signal, then the event listener will be removed

            when signal is aborted.  The event listener is appended to

            target's event listener list and is not appended if it has the

            same type, callback, and capture.

        - dispatchEvent (required):

            Dispatches a synthetic event event to target and returns True

            if either event's cancelable attribute value is False or its

            preventDefault() method was not invoked, and False otherwise.

        - removeEventListener (required):

            Removes the event listener in target's event listener list

            with the same type, callback, and options.

    - classList (dict with strings as keys and values of type string; required):
        Allows for manipulation of element's class content attribute
        as a set of whitespace-separated tokens through a DOMTokenList
        object.

    - className (string; required):
        Returns the value of element's class content attribute. Can be
        set to change it.

    - clientHeight (number; required)

    - clientLeft (number; required)

    - clientTop (number; required)

    - clientWidth (number; required)

    - id (string; required):
        Returns the value of element's id content attribute. Can be
        set to change it.

    - localName (string; required):
        Returns the local name.

    - namespaceURI (string; required):
        Returns the namespace.

    - onfullscreenchange (required)

    - onfullscreenerror (required)

    - outerHTML (string; required)

    - ownerDocument (boolean | number | string | dict | list; required)

    - part (dict with strings as keys and values of type string; required)

    - prefix (string; required):
        Returns the namespace prefix.

    - scrollHeight (number; required)

    - scrollLeft (number; required)

    - scrollTop (number; required)

    - scrollWidth (number; required)

    - shadowRoot (boolean | number | string | dict | list; required):
        Returns element's shadow root, if any, and if shadow root's
        mode is \"open\", and None otherwise.

    - slot (string; required):
        Returns the value of element's slot content attribute. Can be
        set to change it.

    - tagName (string; required):
        Returns the HTML-uppercased qualified name.

    - attachShadow (required):
        Creates a shadow root for element and returns it.

    - closest (dict; required):
        Returns the first (starting at element) inclusive ancestor
        that matches selectors, and None otherwise.

        `closest` is a dict with keys:


    - getAttribute (required):
        Returns element's first attribute whose qualified name is
        qualifiedName, and None if there is no such attribute
        otherwise.

    - getAttributeNS (required):
        Returns element's attribute whose namespace is namespace and
        local name is localName, and None if there is no such
        attribute otherwise.

    - getAttributeNames (required):
        Returns the qualified names of all element's attributes. Can
        contain duplicates.

    - getAttributeNode (required)

    - getAttributeNodeNS (required)

    - getBoundingClientRect (required)

    - getClientRects (required)

    - getElementsByClassName (required):
        Returns a HTMLCollection of the elements in the object on
        which the method was invoked (a document or an element) that
        have all the classes given by classNames. The classNames
        argument is interpreted as a space-separated list of classes.

    - getElementsByTagName (dict; required)

        `getElementsByTagName` is a dict with keys:


    - getElementsByTagNameNS (dict; required)

        `getElementsByTagNameNS` is a dict with keys:


    - hasAttribute (required):
        Returns True if element has an attribute whose qualified name
        is qualifiedName, and False otherwise.

    - hasAttributeNS (required):
        Returns True if element has an attribute whose namespace is
        namespace and local name is localName.

    - hasAttributes (required):
        Returns True if element has attributes, and False otherwise.

    - hasPointerCapture (required)

    - insertAdjacentElement (required)

    - insertAdjacentHTML (required)

    - insertAdjacentText (required)

    - matches (required):
        Returns True if matching selectors against element's root
        yields element, and False otherwise.

    - releasePointerCapture (required)

    - removeAttribute (required):
        Removes element's first attribute whose qualified name is
        qualifiedName.

    - removeAttributeNS (required):
        Removes element's attribute whose namespace is namespace and
        local name is localName.

    - removeAttributeNode (required)

    - requestFullscreen (required):
        Displays element fullscreen and resolves promise when done.
        When supplied, options's navigationUI member indicates whether
        showing navigation UI while in fullscreen is preferred or not.
        If set to \"show\", navigation simplicity is preferred over
        screen space, and if set to \"hide\", more screen space is
        preferred. User agents are always free to honor user
        preference over the application's. The default value \"auto\"
        indicates no application preference.

    - requestPointerLock (required)

    - scroll (dict; required)

        `scroll` is a dict with keys:


    - scrollBy (dict; required)

        `scrollBy` is a dict with keys:


    - scrollIntoView (required)

    - scrollTo (dict; required)

        `scrollTo` is a dict with keys:


    - setAttribute (required):
        Sets the value of element's first attribute whose qualified
        name is qualifiedName to value.

    - setAttributeNS (required):
        Sets the value of element's attribute whose namespace is
        namespace and local name is localName to value.

    - setAttributeNode (required)

    - setAttributeNodeNS (required)

    - setPointerCapture (required)

    - toggleAttribute (required):
        If force is not given, \"toggles\" qualifiedName, removing it
        if it is present and adding it if it is not present. If force
        is True, adds qualifiedName. If force is False, removes
        qualifiedName.  Returns True if qualifiedName is now present,
        and False otherwise.

    - webkitMatchesSelector (required)

    - baseURI (string; required):
        Returns node's node document's document base URL.

    - childNodes (dict with strings as keys and values of type boolean | number | string | dict | list; required):
        Returns the children.

    - firstChild (boolean | number | string | dict | list; required):
        Returns the first child.

    - isConnected (boolean; required):
        Returns True if node is connected and False otherwise.

    - lastChild (boolean | number | string | dict | list; required):
        Returns the last child.

    - nextSibling (boolean | number | string | dict | list; required):
        Returns the next sibling.

    - nodeName (string; required):
        Returns a string appropriate for the type of node.

    - nodeType (number; required):
        Returns the type of node.

    - nodeValue (string; required)

    - parentElement (boolean | number | string | dict | list; required):
        Returns the parent element.

    - parentNode (boolean | number | string | dict | list; required):
        Returns the parent.

    - previousSibling (boolean | number | string | dict | list; required):
        Returns the previous sibling.

    - textContent (string; required)

    - appendChild (required)

    - cloneNode (required):
        Returns a copy of node. If deep is True, the copy also
        includes the node's descendants.

    - compareDocumentPosition (required):
        Returns a bitmask indicating the position of other relative to
        node.

    - contains (required):
        Returns True if other is an inclusive descendant of node, and
        False otherwise.

    - getRootNode (required):
        Returns node's root.

    - hasChildNodes (required):
        Returns whether node has children.

    - insertBefore (required)

    - isDefaultNamespace (required)

    - isEqualNode (required):
        Returns whether node and otherNode have the same properties.

    - isSameNode (required)

    - lookupNamespaceURI (required)

    - lookupPrefix (required)

    - normalize (required):
        Removes empty exclusive Text nodes and concatenates the data
        of remaining contiguous exclusive Text nodes into the first of
        their nodes.

    - removeChild (required)

    - replaceChild (required)

    - ATTRIBUTE_NODE (number; required)

    - CDATA_SECTION_NODE (number; required):
        node is a CDATASection node.

    - COMMENT_NODE (number; required):
        node is a Comment node.

    - DOCUMENT_FRAGMENT_NODE (number; required):
        node is a DocumentFragment node.

    - DOCUMENT_NODE (number; required):
        node is a document.

    - DOCUMENT_POSITION_CONTAINED_BY (number; required):
        Set when other is a descendant of node.

    - DOCUMENT_POSITION_CONTAINS (number; required):
        Set when other is an ancestor of node.

    - DOCUMENT_POSITION_DISCONNECTED (number; required):
        Set when node and other are not in the same tree.

    - DOCUMENT_POSITION_FOLLOWING (number; required):
        Set when other is following node.

    - DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC (number; required)

    - DOCUMENT_POSITION_PRECEDING (number; required):
        Set when other is preceding node.

    - DOCUMENT_TYPE_NODE (number; required):
        node is a doctype.

    - ELEMENT_NODE (number; required):
        node is an element.

    - ENTITY_NODE (number; required)

    - ENTITY_REFERENCE_NODE (number; required)

    - NOTATION_NODE (number; required)

    - PROCESSING_INSTRUCTION_NODE (number; required):
        node is a ProcessingInstruction node.

    - TEXT_NODE (number; required):
        node is a Text node.

    - dispatchEvent (required):
        Dispatches a synthetic event event to target and returns True
        if either event's cancelable attribute value is False or its
        preventDefault() method was not invoked, and False otherwise.

    - ariaAtomic (string; required)

    - ariaAutoComplete (string; required)

    - ariaBusy (string; required)

    - ariaChecked (string; required)

    - ariaColCount (string; required)

    - ariaColIndex (string; required)

    - ariaColIndexText (string; required)

    - ariaColSpan (string; required)

    - ariaCurrent (string; required)

    - ariaDisabled (string; required)

    - ariaExpanded (string; required)

    - ariaHasPopup (string; required)

    - ariaHidden (string; required)

    - ariaInvalid (string; required)

    - ariaKeyShortcuts (string; required)

    - ariaLabel (string; required)

    - ariaLevel (string; required)

    - ariaLive (string; required)

    - ariaModal (string; required)

    - ariaMultiLine (string; required)

    - ariaMultiSelectable (string; required)

    - ariaOrientation (string; required)

    - ariaPlaceholder (string; required)

    - ariaPosInSet (string; required)

    - ariaPressed (string; required)

    - ariaReadOnly (string; required)

    - ariaRequired (string; required)

    - ariaRoleDescription (string; required)

    - ariaRowCount (string; required)

    - ariaRowIndex (string; required)

    - ariaRowIndexText (string; required)

    - ariaRowSpan (string; required)

    - ariaSelected (string; required)

    - ariaSetSize (string; required)

    - ariaSort (string; required)

    - ariaValueMax (string; required)

    - ariaValueMin (string; required)

    - ariaValueNow (string; required)

    - ariaValueText (string; required)

    - role (string; required)

    - animate (required)

    - getAnimations (required)

    - after (required):
        Inserts nodes just after node, while replacing strings in
        nodes with equivalent Text nodes.  Throws a
        \"HierarchyRequestError\" DOMException if the constraints of
        the node tree are violated.

    - before (required):
        Inserts nodes just before node, while replacing strings in
        nodes with equivalent Text nodes.  Throws a
        \"HierarchyRequestError\" DOMException if the constraints of
        the node tree are violated.

    - remove (required):
        Removes node.

    - replaceWith (required):
        Replaces node with nodes, while replacing strings in nodes
        with equivalent Text nodes.  Throws a
        \"HierarchyRequestError\" DOMException if the constraints of
        the node tree are violated.

    - innerHTML (string; required)

    - nextElementSibling (a list of or a singular dash component, string or number; required):
        Returns the first following sibling that is an element, and
        None otherwise.

    - previousElementSibling (a list of or a singular dash component, string or number; required):
        Returns the first preceding sibling that is an element, and
        None otherwise.

    - childElementCount (number; required)

    - children (dict with strings as keys and values of type a list of or a singular dash component, string or number; required):
        Returns the child elements.

    - firstElementChild (a list of or a singular dash component, string or number; required):
        Returns the first child that is an element, and None
        otherwise.

    - lastElementChild (a list of or a singular dash component, string or number; required):
        Returns the last child that is an element, and None otherwise.

    - append (required):
        Inserts nodes after the last child of node, while replacing
        strings in nodes with equivalent Text nodes.  Throws a
        \"HierarchyRequestError\" DOMException if the constraints of
        the node tree are violated.

    - prepend (required):
        Inserts nodes before the first child of node, while replacing
        strings in nodes with equivalent Text nodes.  Throws a
        \"HierarchyRequestError\" DOMException if the constraints of
        the node tree are violated.

    - querySelector (dict; required):
        Returns the first element that is a descendant of node that
        matches selectors.

        `querySelector` is a dict with keys:


    - querySelectorAll (dict; required):
        Returns all element descendants of node that match selectors.

        `querySelectorAll` is a dict with keys:


    - replaceChildren (required):
        Replace all children of node with nodes, while replacing
        strings in nodes with equivalent Text nodes.  Throws a
        \"HierarchyRequestError\" DOMException if the constraints of
        the node tree are violated.

    - assignedSlot (dict; required)

        `assignedSlot` is a dict with keys:

        - name (string; required)

        - assign (required)

        - assignedElements (required)

        - assignedNodes (required)

        - addEventListener (required)

        - removeEventListener (required)

        - accessKey (string; required)

        - accessKeyLabel (string; required)

        - autocapitalize (string; required)

        - dir (string; required)

        - draggable (boolean; required)

        - hidden (boolean; required)

        - inert (boolean; required)

        - innerText (string; required)

        - lang (string; required)

        - offsetHeight (number; required)

        - offsetLeft (number; required)

        - offsetParent (a list of or a singular dash component, string or number; required)

        - offsetTop (number; required)

        - offsetWidth (number; required)

        - outerText (string; required)

        - spellcheck (boolean; required)

        - title (string; required)

        - translate (boolean; required)

        - attachInternals (required)

        - click (required)

        - attributes (dict; required)

            `attributes` is a dict with strings as keys and values of
            type dict with keys:

    - localName (string; required)

    - name (string; required)

    - namespaceURI (string; required)

    - ownerDocument (boolean | number | string | dict | list; required)

    - ownerElement (a list of or a singular dash component, string or number; required)

    - prefix (string; required)

    - specified (boolean; required)

    - value (string; required)

    - baseURI (string; required):
        Returns node's node document's document base URL.

    - childNodes (dict with strings as keys and values of type boolean | number | string | dict | list; required):
        Returns the children.

    - firstChild (boolean | number | string | dict | list; required):
        Returns the first child.

    - isConnected (boolean; required):
        Returns True if node is connected and False otherwise.

    - lastChild (boolean | number | string | dict | list; required):
        Returns the last child.

    - nextSibling (boolean | number | string | dict | list; required):
        Returns the next sibling.

    - nodeName (string; required):
        Returns a string appropriate for the type of node.

    - nodeType (number; required):
        Returns the type of node.

    - nodeValue (string; required)

    - parentElement (boolean | number | string | dict | list; required):
        Returns the parent element.

    - parentNode (boolean | number | string | dict | list; required):
        Returns the parent.

    - previousSibling (boolean | number | string | dict | list; required):
        Returns the previous sibling.

    - textContent (string; required)

    - appendChild (required)

    - cloneNode (required):
        Returns a copy of node. If deep is True, the copy also
        includes the node's descendants.

    - compareDocumentPosition (required):
        Returns a bitmask indicating the position of other relative to
        node.

    - contains (required):
        Returns True if other is an inclusive descendant of node, and
        False otherwise.

    - getRootNode (required):
        Returns node's root.

    - hasChildNodes (required):
        Returns whether node has children.

    - insertBefore (required)

    - isDefaultNamespace (required)

    - isEqualNode (required):
        Returns whether node and otherNode have the same properties.

    - isSameNode (required)

    - lookupNamespaceURI (required)

    - lookupPrefix (required)

    - normalize (required):
        Removes empty exclusive Text nodes and concatenates the data
        of remaining contiguous exclusive Text nodes into the first of
        their nodes.

    - removeChild (required)

    - replaceChild (required)

    - ATTRIBUTE_NODE (number; required)

    - CDATA_SECTION_NODE (number; required):
        node is a CDATASection node.

    - COMMENT_NODE (number; required):
        node is a Comment node.

    - DOCUMENT_FRAGMENT_NODE (number; required):
        node is a DocumentFragment node.

    - DOCUMENT_NODE (number; required):
        node is a document.

    - DOCUMENT_POSITION_CONTAINED_BY (number; required):
        Set when other is a descendant of node.

    - DOCUMENT_POSITION_CONTAINS (number; required):
        Set when other is an ancestor of node.

    - DOCUMENT_POSITION_DISCONNECTED (number; required):
        Set when node and other are not in the same tree.

    - DOCUMENT_POSITION_FOLLOWING (number; required):
        Set when other is following node.

    - DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC (number; required)

    - DOCUMENT_POSITION_PRECEDING (number; required):
        Set when other is preceding node.

    - DOCUMENT_TYPE_NODE (number; required):
        node is a doctype.

    - ELEMENT_NODE (number; required):
        node is an element.

    - ENTITY_NODE (number; required)

    - ENTITY_REFERENCE_NODE (number; required)

    - NOTATION_NODE (number; required)

    - PROCESSING_INSTRUCTION_NODE (number; required):
        node is a ProcessingInstruction node.

    - TEXT_NODE (number; required):
        node is a Text node.

    - addEventListener (required):
        Appends an event listener for events whose type attribute
        value is type. The callback argument sets the callback that
        will be invoked when the event is dispatched.  The options
        argument sets listener-specific options. For compatibility
        this can be a boolean, in which case the method behaves
        exactly as if the value was specified as options's capture.
        When set to True, options's capture prevents callback from
        being invoked when the event's eventPhase attribute value is
        BUBBLING_PHASE. When False (or not present), callback will not
        be invoked when event's eventPhase attribute value is
        CAPTURING_PHASE. Either way, callback will be invoked if
        event's eventPhase attribute value is AT_TARGET.  When set to
        True, options's passive indicates that the callback will not
        cancel the event by invoking preventDefault(). This is used to
        enable performance optimizations described in § 2.8 Observing
        event listeners.  When set to True, options's once indicates
        that the callback will only be invoked once after which the
        event listener will be removed.  If an AbortSignal is passed
        for options's signal, then the event listener will be removed
        when signal is aborted.  The event listener is appended to
        target's event listener list and is not appended if it has the
        same type, callback, and capture.

    - dispatchEvent (required):
        Dispatches a synthetic event event to target and returns True
        if either event's cancelable attribute value is False or its
        preventDefault() method was not invoked, and False otherwise.

    - removeEventListener (required):
        Removes the event listener in target's event listener list
        with the same type, callback, and options.

        - classList (dict with strings as keys and values of type string; required):
            Allows for manipulation of element's class content
            attribute as a set of whitespace-separated tokens through
            a DOMTokenList object.

        - className (string; required):
            Returns the value of element's class content attribute.
            Can be set to change it.

        - clientHeight (number; required)

        - clientLeft (number; required)

        - clientTop (number; required)

        - clientWidth (number; required)

        - id (string; required):
            Returns the value of element's id content attribute. Can
            be set to change it.

        - localName (string; required):
            Returns the local name.

        - namespaceURI (string; required):
            Returns the namespace.

        - onfullscreenchange (required)

        - onfullscreenerror (required)

        - outerHTML (string; required)

        - ownerDocument (boolean | number | string | dict | list; required)

        - part (dict with strings as keys and values of type string; required)

        - prefix (string; required):
            Returns the namespace prefix.

        - scrollHeight (number; required)

        - scrollLeft (number; required)

        - scrollTop (number; required)

        - scrollWidth (number; required)

        - shadowRoot (boolean | number | string | dict | list; required):
            Returns element's shadow root, if any, and if shadow
            root's mode is \"open\", and None otherwise.

        - slot (string; required):
            Returns the value of element's slot content attribute. Can
            be set to change it.

        - tagName (string; required):
            Returns the HTML-uppercased qualified name.

        - attachShadow (required):
            Creates a shadow root for element and returns it.

        - closest (dict; required):
            Returns the first (starting at element) inclusive ancestor
            that matches selectors, and None otherwise.

            `closest` is a dict with keys:


        - getAttribute (required):
            Returns element's first attribute whose qualified name is
            qualifiedName, and None if there is no such attribute
            otherwise.

        - getAttributeNS (required):
            Returns element's attribute whose namespace is namespace
            and local name is localName, and None if there is no such
            attribute otherwise.

        - getAttributeNames (required):
            Returns the qualified names of all element's attributes.
            Can contain duplicates.

        - getAttributeNode (required)

        - getAttributeNodeNS (required)

        - getBoundingClientRect (required)

        - getClientRects (required)

        - getElementsByClassName (required):
            Returns a HTMLCollection of the elements in the object on
            which the method was invoked (a document or an element)
            that have all the classes given by classNames. The
            classNames argument is interpreted as a space-separated
            list of classes.

        - getElementsByTagName (dict; required)

            `getElementsByTagName` is a dict with keys:


        - getElementsByTagNameNS (dict; required)

            `getElementsByTagNameNS` is a dict with keys:


        - hasAttribute (required):
            Returns True if element has an attribute whose qualified
            name is qualifiedName, and False otherwise.

        - hasAttributeNS (required):
            Returns True if element has an attribute whose namespace
            is namespace and local name is localName.

        - hasAttributes (required):
            Returns True if element has attributes, and False
            otherwise.

        - hasPointerCapture (required)

        - insertAdjacentElement (required)

        - insertAdjacentHTML (required)

        - insertAdjacentText (required)

        - matches (required):
            Returns True if matching selectors against element's root
            yields element, and False otherwise.

        - releasePointerCapture (required)

        - removeAttribute (required):
            Removes element's first attribute whose qualified name is
            qualifiedName.

        - removeAttributeNS (required):
            Removes element's attribute whose namespace is namespace
            and local name is localName.

        - removeAttributeNode (required)

        - requestFullscreen (required):
            Displays element fullscreen and resolves promise when
            done.  When supplied, options's navigationUI member
            indicates whether showing navigation UI while in
            fullscreen is preferred or not. If set to \"show\",
            navigation simplicity is preferred over screen space, and
            if set to \"hide\", more screen space is preferred. User
            agents are always free to honor user preference over the
            application's. The default value \"auto\" indicates no
            application preference.

        - requestPointerLock (required)

        - scroll (dict; required)

            `scroll` is a dict with keys:


        - scrollBy (dict; required)

            `scrollBy` is a dict with keys:


        - scrollIntoView (required)

        - scrollTo (dict; required)

            `scrollTo` is a dict with keys:


        - setAttribute (required):
            Sets the value of element's first attribute whose
            qualified name is qualifiedName to value.

        - setAttributeNS (required):
            Sets the value of element's attribute whose namespace is
            namespace and local name is localName to value.

        - setAttributeNode (required)

        - setAttributeNodeNS (required)

        - setPointerCapture (required)

        - toggleAttribute (required):
            If force is not given, \"toggles\" qualifiedName, removing
            it if it is present and adding it if it is not present. If
            force is True, adds qualifiedName. If force is False,
            removes qualifiedName.  Returns True if qualifiedName is
            now present, and False otherwise.

        - webkitMatchesSelector (required)

        - baseURI (string; required):
            Returns node's node document's document base URL.

        - childNodes (dict with strings as keys and values of type boolean | number | string | dict | list; required):
            Returns the children.

        - firstChild (boolean | number | string | dict | list; required):
            Returns the first child.

        - isConnected (boolean; required):
            Returns True if node is connected and False otherwise.

        - lastChild (boolean | number | string | dict | list; required):
            Returns the last child.

        - nextSibling (boolean | number | string | dict | list; required):
            Returns the next sibling.

        - nodeName (string; required):
            Returns a string appropriate for the type of node.

        - nodeType (number; required):
            Returns the type of node.

        - nodeValue (string; required)

        - parentElement (boolean | number | string | dict | list; required):
            Returns the parent element.

        - parentNode (boolean | number | string | dict | list; required):
            Returns the parent.

        - previousSibling (boolean | number | string | dict | list; required):
            Returns the previous sibling.

        - textContent (string; required)

        - appendChild (required)

        - cloneNode (required):
            Returns a copy of node. If deep is True, the copy also
            includes the node's descendants.

        - compareDocumentPosition (required):
            Returns a bitmask indicating the position of other
            relative to node.

        - contains (required):
            Returns True if other is an inclusive descendant of node,
            and False otherwise.

        - getRootNode (required):
            Returns node's root.

        - hasChildNodes (required):
            Returns whether node has children.

        - insertBefore (required)

        - isDefaultNamespace (required)

        - isEqualNode (required):
            Returns whether node and otherNode have the same
            properties.

        - isSameNode (required)

        - lookupNamespaceURI (required)

        - lookupPrefix (required)

        - normalize (required):
            Removes empty exclusive Text nodes and concatenates the
            data of remaining contiguous exclusive Text nodes into the
            first of their nodes.

        - removeChild (required)

        - replaceChild (required)

        - ATTRIBUTE_NODE (number; required)

        - CDATA_SECTION_NODE (number; required):
            node is a CDATASection node.

        - COMMENT_NODE (number; required):
            node is a Comment node.

        - DOCUMENT_FRAGMENT_NODE (number; required):
            node is a DocumentFragment node.

        - DOCUMENT_NODE (number; required):
            node is a document.

        - DOCUMENT_POSITION_CONTAINED_BY (number; required):
            Set when other is a descendant of node.

        - DOCUMENT_POSITION_CONTAINS (number; required):
            Set when other is an ancestor of node.

        - DOCUMENT_POSITION_DISCONNECTED (number; required):
            Set when node and other are not in the same tree.

        - DOCUMENT_POSITION_FOLLOWING (number; required):
            Set when other is following node.

        - DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC (number; required)

        - DOCUMENT_POSITION_PRECEDING (number; required):
            Set when other is preceding node.

        - DOCUMENT_TYPE_NODE (number; required):
            node is a doctype.

        - ELEMENT_NODE (number; required):
            node is an element.

        - ENTITY_NODE (number; required)

        - ENTITY_REFERENCE_NODE (number; required)

        - NOTATION_NODE (number; required)

        - PROCESSING_INSTRUCTION_NODE (number; required):
            node is a ProcessingInstruction node.

        - TEXT_NODE (number; required):
            node is a Text node.

        - dispatchEvent (required):
            Dispatches a synthetic event event to target and returns
            True if either event's cancelable attribute value is False
            or its preventDefault() method was not invoked, and False
            otherwise.

        - ariaAtomic (string; required)

        - ariaAutoComplete (string; required)

        - ariaBusy (string; required)

        - ariaChecked (string; required)

        - ariaColCount (string; required)

        - ariaColIndex (string; required)

        - ariaColIndexText (string; required)

        - ariaColSpan (string; required)

        - ariaCurrent (string; required)

        - ariaDisabled (string; required)

        - ariaExpanded (string; required)

        - ariaHasPopup (string; required)

        - ariaHidden (string; required)

        - ariaInvalid (string; required)

        - ariaKeyShortcuts (string; required)

        - ariaLabel (string; required)

        - ariaLevel (string; required)

        - ariaLive (string; required)

        - ariaModal (string; required)

        - ariaMultiLine (string; required)

        - ariaMultiSelectable (string; required)

        - ariaOrientation (string; required)

        - ariaPlaceholder (string; required)

        - ariaPosInSet (string; required)

        - ariaPressed (string; required)

        - ariaReadOnly (string; required)

        - ariaRequired (string; required)

        - ariaRoleDescription (string; required)

        - ariaRowCount (string; required)

        - ariaRowIndex (string; required)

        - ariaRowIndexText (string; required)

        - ariaRowSpan (string; required)

        - ariaSelected (string; required)

        - ariaSetSize (string; required)

        - ariaSort (string; required)

        - ariaValueMax (string; required)

        - ariaValueMin (string; required)

        - ariaValueNow (string; required)

        - ariaValueText (string; required)

        - role (string; required)

        - animate (required)

        - getAnimations (required)

        - after (required):
            Inserts nodes just after node, while replacing strings in
            nodes with equivalent Text nodes.  Throws a
            \"HierarchyRequestError\" DOMException if the constraints
            of the node tree are violated.

        - before (required):
            Inserts nodes just before node, while replacing strings in
            nodes with equivalent Text nodes.  Throws a
            \"HierarchyRequestError\" DOMException if the constraints
            of the node tree are violated.

        - remove (required):
            Removes node.

        - replaceWith (required):
            Replaces node with nodes, while replacing strings in nodes
            with equivalent Text nodes.  Throws a
            \"HierarchyRequestError\" DOMException if the constraints
            of the node tree are violated.

        - innerHTML (string; required)

        - nextElementSibling (a list of or a singular dash component, string or number; required):
            Returns the first following sibling that is an element,
            and None otherwise.

        - previousElementSibling (a list of or a singular dash component, string or number; required):
            Returns the first preceding sibling that is an element,
            and None otherwise.

        - childElementCount (number; required)

        - children (dict with strings as keys and values of type a list of or a singular dash component, string or number; required):
            Returns the child elements.

        - firstElementChild (a list of or a singular dash component, string or number; required):
            Returns the first child that is an element, and None
            otherwise.

        - lastElementChild (a list of or a singular dash component, string or number; required):
            Returns the last child that is an element, and None
            otherwise.

        - append (required):
            Inserts nodes after the last child of node, while
            replacing strings in nodes with equivalent Text nodes.
            Throws a \"HierarchyRequestError\" DOMException if the
            constraints of the node tree are violated.

        - prepend (required):
            Inserts nodes before the first child of node, while
            replacing strings in nodes with equivalent Text nodes.
            Throws a \"HierarchyRequestError\" DOMException if the
            constraints of the node tree are violated.

        - querySelector (dict; required):
            Returns the first element that is a descendant of node
            that matches selectors.

            `querySelector` is a dict with keys:


        - querySelectorAll (dict; required):
            Returns all element descendants of node that match
            selectors.

            `querySelectorAll` is a dict with keys:


        - replaceChildren (required):
            Replace all children of node with nodes, while replacing
            strings in nodes with equivalent Text nodes.  Throws a
            \"HierarchyRequestError\" DOMException if the constraints
            of the node tree are violated.

        - assignedSlot (boolean | number | string | dict | list; required)

        - oncopy (required)

        - oncut (required)

        - onpaste (required)

        - style (dict with strings as keys and values of type string; required)

        - contentEditable (string; required)

        - enterKeyHint (string; required)

        - inputMode (string; required)

        - isContentEditable (boolean; required)

        - onabort (required):
            Fires when the user aborts the download. @,param,ev, ,The
            event.

        - onanimationcancel (required)

        - onanimationend (required)

        - onanimationiteration (required)

        - onanimationstart (required)

        - onauxclick (required)

        - onbeforeinput (required)

        - onblur (required):
            Fires when the object loses the input focus. @,param,ev,
            ,The focus event.

        - oncancel (required)

        - oncanplay (required):
            Occurs when playback is possible, but would require
            further buffering. @,param,ev, ,The event.

        - oncanplaythrough (required)

        - onchange (required):
            Fires when the contents of the object or selection have
            changed. @,param,ev, ,The event.

        - onclick (required):
            Fires when the user clicks the left mouse button on the
            object @,param,ev, ,The mouse event.

        - onclose (required)

        - oncontextmenu (required):
            Fires when the user clicks the right mouse button in the
            client area, opening the context menu. @,param,ev, ,The
            mouse event.

        - oncuechange (required)

        - ondblclick (required):
            Fires when the user double-clicks the object. @,param,ev,
            ,The mouse event.

        - ondrag (required):
            Fires on the source object continuously during a drag
            operation. @,param,ev, ,The event.

        - ondragend (required):
            Fires on the source object when the user releases the
            mouse at the close of a drag operation. @,param,ev, ,The
            event.

        - ondragenter (required):
            Fires on the target element when the user drags the object
            to a valid drop target. @,param,ev, ,The drag event.

        - ondragleave (required):
            Fires on the target object when the user moves the mouse
            out of a valid drop target during a drag operation.
            @,param,ev, ,The drag event.

        - ondragover (required):
            Fires on the target element continuously while the user
            drags the object over a valid drop target. @,param,ev,
            ,The event.

        - ondragstart (required):
            Fires on the source object when the user starts to drag a
            text selection or selected object. @,param,ev, ,The event.

        - ondrop (required)

        - ondurationchange (required):
            Occurs when the duration attribute is updated. @,param,ev,
            ,The event.

        - onemptied (required):
            Occurs when the media element is reset to its initial
            state. @,param,ev, ,The event.

        - onended (required):
            Occurs when the end of playback is reached. @,param,ev,
            ,The event.

        - onerror (dict; required):
            Fires when an error occurs during object loading.
            @,param,ev, ,The event.

            `onerror` is a dict with keys:


        - onfocus (required):
            Fires when the object receives focus. @,param,ev, ,The
            event.

        - onformdata (required)

        - ongotpointercapture (required)

        - oninput (required)

        - oninvalid (required)

        - onkeydown (required):
            Fires when the user presses a key. @,param,ev, ,The
            keyboard event.

        - onkeypress (required):
            Fires when the user presses an alphanumeric key.
            @,param,ev, ,The event. @,deprecated.

        - onkeyup (required):
            Fires when the user releases a key. @,param,ev, ,The
            keyboard event.

        - onload (required):
            Fires immediately after the browser loads the object.
            @,param,ev, ,The event.

        - onloadeddata (required):
            Occurs when media data is loaded at the current playback
            position. @,param,ev, ,The event.

        - onloadedmetadata (required):
            Occurs when the duration and dimensions of the media have
            been determined. @,param,ev, ,The event.

        - onloadstart (required):
            Occurs when Internet Explorer begins looking for media
            data. @,param,ev, ,The event.

        - onlostpointercapture (required)

        - onmousedown (required):
            Fires when the user clicks the object with either mouse
            button. @,param,ev, ,The mouse event.

        - onmouseenter (required)

        - onmouseleave (required)

        - onmousemove (required):
            Fires when the user moves the mouse over the object.
            @,param,ev, ,The mouse event.

        - onmouseout (required):
            Fires when the user moves the mouse pointer outside the
            boundaries of the object. @,param,ev, ,The mouse event.

        - onmouseover (required):
            Fires when the user moves the mouse pointer into the
            object. @,param,ev, ,The mouse event.

        - onmouseup (required):
            Fires when the user releases a mouse button while the
            mouse is over the object. @,param,ev, ,The mouse event.

        - onpause (required):
            Occurs when playback is paused. @,param,ev, ,The event.

        - onplay (required):
            Occurs when the play method is requested. @,param,ev, ,The
            event.

        - onplaying (required):
            Occurs when the audio or video has started playing.
            @,param,ev, ,The event.

        - onpointercancel (required)

        - onpointerdown (required)

        - onpointerenter (required)

        - onpointerleave (required)

        - onpointermove (required)

        - onpointerout (required)

        - onpointerover (required)

        - onpointerup (required)

        - onprogress (required):
            Occurs to indicate progress while downloading media data.
            @,param,ev, ,The event.

        - onratechange (required):
            Occurs when the playback rate is increased or decreased.
            @,param,ev, ,The event.

        - onreset (required):
            Fires when the user resets a form. @,param,ev, ,The event.

        - onresize (required)

        - onscroll (required):
            Fires when the user repositions the scroll box in the
            scroll bar on the object. @,param,ev, ,The event.

        - onsecuritypolicyviolation (required)

        - onseeked (required):
            Occurs when the seek operation ends. @,param,ev, ,The
            event.

        - onseeking (required):
            Occurs when the current playback position is moved.
            @,param,ev, ,The event.

        - onselect (required):
            Fires when the current selection changes. @,param,ev, ,The
            event.

        - onselectionchange (required)

        - onselectstart (required)

        - onslotchange (required)

        - onstalled (required):
            Occurs when the download has stopped. @,param,ev, ,The
            event.

        - onsubmit (required)

        - onsuspend (required):
            Occurs if the load operation has been intentionally
            halted. @,param,ev, ,The event.

        - ontimeupdate (required):
            Occurs to indicate the current playback position.
            @,param,ev, ,The event.

        - ontoggle (required)

        - ontouchcancel (optional)

        - ontouchend (optional)

        - ontouchmove (optional)

        - ontouchstart (optional)

        - ontransitioncancel (required)

        - ontransitionend (required)

        - ontransitionrun (required)

        - ontransitionstart (required)

        - onvolumechange (required):
            Occurs when the volume is changed, or playback is muted or
            unmuted. @,param,ev, ,The event.

        - onwaiting (required):
            Occurs when playback stops because the next frame of a
            video resource is not available. @,param,ev, ,The event.

        - onwebkitanimationend (required)

        - onwebkitanimationiteration (required)

        - onwebkitanimationstart (required)

        - onwebkittransitionend (required)

        - onwheel (required)

        - autofocus (boolean; required)

        - dataset (dict with strings as keys and values of type string; required)

        - nonce (string; optional)

        - tabIndex (number; required)

        - blur (required)

        - focus (required)

    - oncopy (required)

    - oncut (required)

    - onpaste (required)

    - style (dict with strings as keys and values of type string; required)

    - contentEditable (string; required)

    - enterKeyHint (string; required)

    - inputMode (string; required)

    - isContentEditable (boolean; required)

    - onabort (required):
        Fires when the user aborts the download. @,param,ev, ,The
        event.

    - onanimationcancel (required)

    - onanimationend (required)

    - onanimationiteration (required)

    - onanimationstart (required)

    - onauxclick (required)

    - onbeforeinput (required)

    - onblur (required):
        Fires when the object loses the input focus. @,param,ev, ,The
        focus event.

    - oncancel (required)

    - oncanplay (required):
        Occurs when playback is possible, but would require further
        buffering. @,param,ev, ,The event.

    - oncanplaythrough (required)

    - onchange (required):
        Fires when the contents of the object or selection have
        changed. @,param,ev, ,The event.

    - onclick (required):
        Fires when the user clicks the left mouse button on the object
        @,param,ev, ,The mouse event.

    - onclose (required)

    - oncontextmenu (required):
        Fires when the user clicks the right mouse button in the
        client area, opening the context menu. @,param,ev, ,The mouse
        event.

    - oncuechange (required)

    - ondblclick (required):
        Fires when the user double-clicks the object. @,param,ev, ,The
        mouse event.

    - ondrag (required):
        Fires on the source object continuously during a drag
        operation. @,param,ev, ,The event.

    - ondragend (required):
        Fires on the source object when the user releases the mouse at
        the close of a drag operation. @,param,ev, ,The event.

    - ondragenter (required):
        Fires on the target element when the user drags the object to
        a valid drop target. @,param,ev, ,The drag event.

    - ondragleave (required):
        Fires on the target object when the user moves the mouse out
        of a valid drop target during a drag operation. @,param,ev,
        ,The drag event.

    - ondragover (required):
        Fires on the target element continuously while the user drags
        the object over a valid drop target. @,param,ev, ,The event.

    - ondragstart (required):
        Fires on the source object when the user starts to drag a text
        selection or selected object. @,param,ev, ,The event.

    - ondrop (required)

    - ondurationchange (required):
        Occurs when the duration attribute is updated. @,param,ev,
        ,The event.

    - onemptied (required):
        Occurs when the media element is reset to its initial state.
        @,param,ev, ,The event.

    - onended (required):
        Occurs when the end of playback is reached. @,param,ev, ,The
        event.

    - onerror (dict; required):
        Fires when an error occurs during object loading. @,param,ev,
        ,The event.

        `onerror` is a dict with keys:


    - onfocus (required):
        Fires when the object receives focus. @,param,ev, ,The event.

    - onformdata (required)

    - ongotpointercapture (required)

    - oninput (required)

    - oninvalid (required)

    - onkeydown (required):
        Fires when the user presses a key. @,param,ev, ,The keyboard
        event.

    - onkeypress (required):
        Fires when the user presses an alphanumeric key. @,param,ev,
        ,The event. @,deprecated.

    - onkeyup (required):
        Fires when the user releases a key. @,param,ev, ,The keyboard
        event.

    - onload (required):
        Fires immediately after the browser loads the object.
        @,param,ev, ,The event.

    - onloadeddata (required):
        Occurs when media data is loaded at the current playback
        position. @,param,ev, ,The event.

    - onloadedmetadata (required):
        Occurs when the duration and dimensions of the media have been
        determined. @,param,ev, ,The event.

    - onloadstart (required):
        Occurs when Internet Explorer begins looking for media data.
        @,param,ev, ,The event.

    - onlostpointercapture (required)

    - onmousedown (required):
        Fires when the user clicks the object with either mouse
        button. @,param,ev, ,The mouse event.

    - onmouseenter (required)

    - onmouseleave (required)

    - onmousemove (required):
        Fires when the user moves the mouse over the object.
        @,param,ev, ,The mouse event.

    - onmouseout (required):
        Fires when the user moves the mouse pointer outside the
        boundaries of the object. @,param,ev, ,The mouse event.

    - onmouseover (required):
        Fires when the user moves the mouse pointer into the object.
        @,param,ev, ,The mouse event.

    - onmouseup (required):
        Fires when the user releases a mouse button while the mouse is
        over the object. @,param,ev, ,The mouse event.

    - onpause (required):
        Occurs when playback is paused. @,param,ev, ,The event.

    - onplay (required):
        Occurs when the play method is requested. @,param,ev, ,The
        event.

    - onplaying (required):
        Occurs when the audio or video has started playing.
        @,param,ev, ,The event.

    - onpointercancel (required)

    - onpointerdown (required)

    - onpointerenter (required)

    - onpointerleave (required)

    - onpointermove (required)

    - onpointerout (required)

    - onpointerover (required)

    - onpointerup (required)

    - onprogress (required):
        Occurs to indicate progress while downloading media data.
        @,param,ev, ,The event.

    - onratechange (required):
        Occurs when the playback rate is increased or decreased.
        @,param,ev, ,The event.

    - onreset (required):
        Fires when the user resets a form. @,param,ev, ,The event.

    - onresize (required)

    - onscroll (required):
        Fires when the user repositions the scroll box in the scroll
        bar on the object. @,param,ev, ,The event.

    - onsecuritypolicyviolation (required)

    - onseeked (required):
        Occurs when the seek operation ends. @,param,ev, ,The event.

    - onseeking (required):
        Occurs when the current playback position is moved.
        @,param,ev, ,The event.

    - onselect (required):
        Fires when the current selection changes. @,param,ev, ,The
        event.

    - onselectionchange (required)

    - onselectstart (required)

    - onslotchange (required)

    - onstalled (required):
        Occurs when the download has stopped. @,param,ev, ,The event.

    - onsubmit (required)

    - onsuspend (required):
        Occurs if the load operation has been intentionally halted.
        @,param,ev, ,The event.

    - ontimeupdate (required):
        Occurs to indicate the current playback position. @,param,ev,
        ,The event.

    - ontoggle (required)

    - ontouchcancel (optional)

    - ontouchend (optional)

    - ontouchmove (optional)

    - ontouchstart (optional)

    - ontransitioncancel (required)

    - ontransitionend (required)

    - ontransitionrun (required)

    - ontransitionstart (required)

    - onvolumechange (required):
        Occurs when the volume is changed, or playback is muted or
        unmuted. @,param,ev, ,The event.

    - onwaiting (required):
        Occurs when playback stops because the next frame of a video
        resource is not available. @,param,ev, ,The event.

    - onwebkitanimationend (required)

    - onwebkitanimationiteration (required)

    - onwebkitanimationstart (required)

    - onwebkittransitionend (required)

    - onwheel (required)

    - autofocus (boolean; required)

    - dataset (dict with strings as keys and values of type string; required)

    - nonce (string; optional)

    - tabIndex (number; required)

    - blur (required)

    - focus (required)

- dblclickData (dict; optional):
    An object holding data related to the double click event. Typing
    is indicative.

    `dblclickData` is a dict with keys:

    - latlng (list of numbers; required)

    - layerPoint (list of numbers; required)

    - containerPoint (list of numbers; required)

- direction (a value equal to: 'center', 'right', 'left', 'top', 'bottom', 'auto'; optional):
    Direction where to open the tooltip. Possible values are: right,
    left, top, bottom, center, auto. auto will dynamically switch
    between right and left according to the tooltip position on the
    map.

- disableDefaultEventHandlers (boolean; optional):
    If set to True, default events handlers are not registered.
    [MUTABLE].

- eventHandlers (dict; optional):
    Object with keys specifying the event type and the value the
    corresponding event handlers. [MUTABLE].

- interactive (boolean; optional):
    If True, the popup/tooltip will listen to the mouse events.

- loading_state (dict; optional):
    Dash loading state information.

- n_clicks (number; optional):
    An integer that represents the number of times that this element
    has been clicked on.

- n_dblclicks (number; optional):
    An integer that represents the number of times that this element
    has been double-clicked on.

- offset (dict; optional):
    The offset of the popup position.

    `offset` is a dict with keys:

    - clone (required)

    - add (required)

    - subtract (required)

    - divideBy (required)

    - multiplyBy (required)

    - scaleBy (required)

    - unscaleBy (required)

    - round (required)

    - floor (required)

    - ceil (required)

    - trunc (required)

    - distanceTo (required)

    - equals (required)

    - contains (required)

    - toString (optional)

    - x (number; required)

    - y (number; required)

- opacity (number; optional):
    Tooltip container opacity.

- pane (string; optional):
    Map pane where the layer will be added.

- permanent (boolean; optional):
    Whether to open the tooltip permanently or only on mouseover.

- position (dict; optional):
    A geographical point in (lat, lon) format. [MUTABLE].

    `position` is a dict with keys:

    - equals (required)

    - toString (optional)

    - distanceTo (required)

    - wrap (required)

    - toBounds (required)

    - clone (required)

    - lat (number; required)

    - lng (number; required)

    - alt (number; optional)

- sticky (boolean; optional):
    If True, the tooltip will follow the mouse instead of being fixed
    at the feature center."""
    _children_props = ['content.offsetParent', 'content.attributes{}.ownerElement', 'content.nextElementSibling', 'content.previousElementSibling', 'content.children{}', 'content.firstElementChild', 'content.lastElementChild', 'content.assignedSlot.offsetParent', 'content.assignedSlot.attributes{}.ownerElement', 'content.assignedSlot.nextElementSibling', 'content.assignedSlot.previousElementSibling', 'content.assignedSlot.children{}', 'content.assignedSlot.firstElementChild', 'content.assignedSlot.lastElementChild']
    _base_nodes = ['children']
    _namespace = 'dash_leaflet'
    _type = 'Tooltip'
    @_explicitize_args
    def __init__(self, children=None, opacity=Component.UNDEFINED, className=Component.UNDEFINED, interactive=Component.UNDEFINED, bubblingMouseEvents=Component.UNDEFINED, pane=Component.UNDEFINED, attribution=Component.UNDEFINED, position=Component.UNDEFINED, content=Component.UNDEFINED, offset=Component.UNDEFINED, direction=Component.UNDEFINED, permanent=Component.UNDEFINED, sticky=Component.UNDEFINED, id=Component.UNDEFINED, loading_state=Component.UNDEFINED, eventHandlers=Component.UNDEFINED, disableDefaultEventHandlers=Component.UNDEFINED, n_clicks=Component.UNDEFINED, clickData=Component.UNDEFINED, n_dblclicks=Component.UNDEFINED, dblclickData=Component.UNDEFINED, **kwargs):
        self._prop_names = ['children', 'id', 'attribution', 'bubblingMouseEvents', 'className', 'clickData', 'content', 'dblclickData', 'direction', 'disableDefaultEventHandlers', 'eventHandlers', 'interactive', 'loading_state', 'n_clicks', 'n_dblclicks', 'offset', 'opacity', 'pane', 'permanent', 'position', 'sticky']
        self._valid_wildcard_attributes =            []
        self.available_properties = ['children', 'id', 'attribution', 'bubblingMouseEvents', 'className', 'clickData', 'content', 'dblclickData', 'direction', 'disableDefaultEventHandlers', 'eventHandlers', 'interactive', 'loading_state', 'n_clicks', 'n_dblclicks', 'offset', 'opacity', 'pane', 'permanent', 'position', 'sticky']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs and excess named props
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}

        super(Tooltip, self).__init__(children=children, **args)
