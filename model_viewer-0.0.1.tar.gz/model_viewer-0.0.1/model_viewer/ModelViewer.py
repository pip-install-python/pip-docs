# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class ModelViewer(Component):
    """A ModelViewer component.


Keyword arguments:

- id (string; required):
    Component ID.

- alt (string; required):
    Alt text for accessibility.

- ar (boolean; default True):
    Enable AR features.

- arButtonText (string; default 'View in your space'):
    Text for the default AR button.

- arModes (string; default "basic_annotations scene-viewer quick-look")

- arScale (a value equal to: 'auto', 'fixed'; default 'auto')

- cameraControls (boolean; default True):
    Enable camera controls.

- cameraOrbit (string; default undefined):
    Initial camera orbital position ($theta $phi $radius).

- cameraTarget (string; default undefined):
    Initial camera target point ($X $Y $Z).

- customArFailure (a list of or a singular dash component, string or number; optional):
    Custom React element for the AR failure message.

- customArPrompt (a list of or a singular dash component, string or number; optional):
    Custom React element for the AR prompt.

- fieldOfView (string; default 'auto'):
    Camera field of view.

- hotspots (list of dicts; optional):
    Array of hotspot objects passed from the server.

    `hotspots` is a list of dicts with keys:

    - children_classname (string; optional)

    - fov (string; optional)

    - normal (string; optional)

    - orbit (string; optional)

    - position (string; optional)

    - slot (string; optional)

    - target (string; optional)

    - text (string; optional)

- interpolationDecay (number | string; default 50):
    Camera interpolation decay rate.

- maxCameraOrbit (string; default 'auto auto auto'):
    Maximum camera orbit bounds.

- maxFieldOfView (string; default 'auto'):
    Maximum camera field of view.

- minCameraOrbit (string; default 'auto auto auto'):
    Minimum camera orbit bounds.

- minFieldOfView (string; default '25deg'):
    Minimum camera field of view.

- poster (string; default undefined):
    Poster image URL.

- shadowIntensity (number | string; default 0)

- src (string; required):
    Model source URL (.glb or .gltf).

- style (dict; optional):
    CSS Style object.

- toneMapping (a value equal to: 'neutral', 'aces', 'agx', 'reinhard', 'cineon', 'linear', 'none'; default 'neutral')

- touchAction (a value equal to: 'pan-y', 'pan-x', 'none'; default "pan-y"):
    Touch action behavior.

- variantName (string; optional)"""
    _children_props = ['customArPrompt', 'customArFailure']
    _base_nodes = ['customArPrompt', 'customArFailure', 'children']
    _namespace = 'model_viewer'
    _type = 'ModelViewer'
    @_explicitize_args
    def __init__(self, id=Component.REQUIRED, src=Component.REQUIRED, alt=Component.REQUIRED, cameraControls=Component.UNDEFINED, touchAction=Component.UNDEFINED, cameraOrbit=Component.UNDEFINED, cameraTarget=Component.UNDEFINED, fieldOfView=Component.UNDEFINED, minFieldOfView=Component.UNDEFINED, maxFieldOfView=Component.UNDEFINED, interpolationDecay=Component.UNDEFINED, minCameraOrbit=Component.UNDEFINED, maxCameraOrbit=Component.UNDEFINED, poster=Component.UNDEFINED, ar=Component.UNDEFINED, hotspots=Component.UNDEFINED, arButtonText=Component.UNDEFINED, customArPrompt=Component.UNDEFINED, customArFailure=Component.UNDEFINED, style=Component.UNDEFINED, toneMapping=Component.UNDEFINED, arModes=Component.UNDEFINED, shadowIntensity=Component.UNDEFINED, arScale=Component.UNDEFINED, variantName=Component.UNDEFINED, **kwargs):
        self._prop_names = ['id', 'alt', 'ar', 'arButtonText', 'arModes', 'arScale', 'cameraControls', 'cameraOrbit', 'cameraTarget', 'customArFailure', 'customArPrompt', 'fieldOfView', 'hotspots', 'interpolationDecay', 'maxCameraOrbit', 'maxFieldOfView', 'minCameraOrbit', 'minFieldOfView', 'poster', 'shadowIntensity', 'src', 'style', 'toneMapping', 'touchAction', 'variantName']
        self._valid_wildcard_attributes =            []
        self.available_properties = ['id', 'alt', 'ar', 'arButtonText', 'arModes', 'arScale', 'cameraControls', 'cameraOrbit', 'cameraTarget', 'customArFailure', 'customArPrompt', 'fieldOfView', 'hotspots', 'interpolationDecay', 'maxCameraOrbit', 'maxFieldOfView', 'minCameraOrbit', 'minFieldOfView', 'poster', 'shadowIntensity', 'src', 'style', 'toneMapping', 'touchAction', 'variantName']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs and excess named props
        args = {k: _locals[k] for k in _explicit_args}

        for k in ['id', 'alt', 'src']:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')

        super(ModelViewer, self).__init__(**args)
